var store = [{
        "title": "Jill",
        "excerpt":"Jill is an avid fruit grower based in the south of France. ","categories": [],
        "tags": [],
        "url": "https://keszeitheone.github.io/authors/jill/"
      },{
        "title": "Keszei",
        "excerpt":"Jill is an avid fruit grower based in the south of France. ","categories": [],
        "tags": [],
        "url": "https://keszeitheone.github.io/authors/keszei/"
      },{
        "title": "Ted",
        "excerpt":"Ted has been eating fruit since he was baby. ","categories": [],
        "tags": [],
        "url": "https://keszeitheone.github.io/authors/ted/"
      },{
        "title": "Kiwifruit",
        "excerpt":"Kiwifruit (often abbreviated as kiwi), or Chinese gooseberry is the edibleberry of several species of woody vines in the genus Actinidia. The most common cultivar group of kiwifruit is oval, about the size of a largehen’s egg (5–8 cm (2.0–3.1 in) in length and 4.5–5.5 cm (1.8–2.2 in) indiameter). It...","categories": ["fruit"],
        "tags": [],
        "url": "https://keszeitheone.github.io/fruit/kiwifruit/"
      },{
        "title": "Bananas",
        "excerpt":"A banana is an edible fruit – botanically a berry – produced by several kindsof large herbaceous flowering plants in the genus Musa. In some countries, bananas used for cooking may be called “plantains”,distinguishing them from dessert bananas. The fruit is variable in size, color,and firmness, but is usually elongated...","categories": ["fruit"],
        "tags": [],
        "url": "https://keszeitheone.github.io/fruit/bananas/"
      },{
        "title": "Apples",
        "excerpt":"An apple is a sweet, edible fruit produced by an apple tree. Apple trees are cultivated worldwide, and are the most widely grown species inthe genus Malus. The tree originated in Central Asia, where its wild ancestor,Malus sieversii, is still found today. Apples have been grown for thousands ofyears in...","categories": ["fruit"],
        "tags": [],
        "url": "https://keszeitheone.github.io/fruit/apples/"
      },]
